# test page

Tag <mark>\{\{ git_revision_date_localized \}\}</mark> renders as: {{ git_revision_date_localized }}

Tag <mark>\{\{ git_creation_date_localized \}\}</mark> renders as: {{ git_creation_date_localized }}

Tag <mark>\{\{ git_site_revision_date_localized \}\}</mark> renders as: {{ git_site_revision_date_localized }}

