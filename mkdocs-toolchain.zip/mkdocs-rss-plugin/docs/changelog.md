---
title: Changelog for the MkDocs RSS Plugin
description: "Changelog of the RSS plugin for MkDocs."
categories: ["Release notes", "test"]
---

--8<-- "CHANGELOG.md"
